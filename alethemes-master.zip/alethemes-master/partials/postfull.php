<section class="full"><?php if (is_single()) : ?>
    <?php ale_part('postcontent');?>
    <?php ale_part('postline'); ?>
<?php endif; ?></section>
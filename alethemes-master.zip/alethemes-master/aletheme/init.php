<?php
// include system functions
require_once ALETHEME_PATH . '/constants.php';

if (!isset( $content_width)) {
	$content_width = 1000; // default content width
}